For information about markers, consult the documentation:

https://docs.openshift.org/origin-m4/oo_user_guide.html#using-cartridges
